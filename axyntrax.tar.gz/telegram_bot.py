# -*- coding: utf-8 -*-
"""
JARVIS AX - Bot de Telegram (Motor Audiovisual con Edge-TTS)
Conectado al Cerebro Central (Core API)
"""
import os
import sys
import json
import uuid
import base64
import asyncio
import requests
from telegram import Update
from telegram.ext import Application, MessageHandler, filters, ContextTypes, CommandHandler
from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv(r"C:\AXYNTRAX\.env")

# Configuración
TELEGRAM_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')

if not TELEGRAM_TOKEN:
    print("❌ Faltan TELEGRAM_BOT_TOKEN en variables de entorno")
    sys.exit(1)

# Motor TTS: Edge-TTS
VOICE_MODEL = "es-MX-JorgeNeural" # Voz corporativa, neutra y grave

async def generar_audio(texto: str) -> str:
    """Genera archivo de voz y retorna la ruta"""
    import edge_tts
    filepath = f"voice_cache_{uuid.uuid4().hex[:8]}.ogg"
    communicate = edge_tts.Communicate(texto, VOICE_MODEL)
    await communicate.save(filepath)
    return filepath

# Motor Visual: Playwright
async def capturar_hud() -> str:
    """Toma un screenshot silencioso del HUD"""
    from playwright.async_api import async_playwright
    filepath = f"hud_shot_{uuid.uuid4().hex[:8]}.png"
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        try:
            # Apuntar al HUD local
            await page.goto('http://localhost:3002', timeout=10000, wait_until='networkidle')
            await asyncio.sleep(2) # Dar tiempo a animaciones y WebSocket
            await page.screenshot(path=filepath, full_page=True)
        except Exception as e:
            print(f"Error capturando HUD: {e}")
        finally:
            await browser.close()
    return filepath

# Comandos Básicos
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_name = update.message.from_user.first_name
    msg = f"✨ *JARVIS Motor Audiovisual Online*\n\nHola {user_name}. Mi núcleo vocal ha sido reparado. Mis sensores visuales están en línea.\n\nComandos:\n/hud - Capturar pantalla del sistema\nEnvía un audio y te responderé con mi nueva voz."
    await update.message.reply_text(msg, parse_mode='Markdown')

async def hud_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status_msg = await update.message.reply_text("📸 *Tomando captura satelital del HUD...*", parse_mode='Markdown')
    try:
        shot_path = await capturar_hud()
        if os.path.exists(shot_path):
            with open(shot_path, 'rb') as photo:
                await context.bot.send_photo(chat_id=update.message.from_user.id, photo=photo, caption="🌐 Matriz de Comando AXYNTRAX actual.")
            os.remove(shot_path)
            await status_msg.delete()
        else:
            await status_msg.edit_text("❌ Falla en la cámara del sistema.")
    except Exception as e:
        await status_msg.edit_text(f"❌ Error visual: {e}")

# Transcripción de Audio
async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    status_msg = await update.message.reply_text("🎧 _Escuchando..._", parse_mode='Markdown')
    
    try:
        voice_file = await context.bot.get_file(update.message.voice.file_id)
        file_bytes = await voice_file.download_as_bytearray()
        
        if not GEMINI_API_KEY:
            raise Exception("Falta GEMINI_API_KEY para transcripción.")
            
        b64_audio = base64.b64encode(file_bytes).decode('utf-8')
        
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
        payload = {
            "contents": [{
                "parts": [
                    {"text": "Transcribe exactamente el siguiente audio. Devuelve SOLO el texto transcrito."},
                    {"inline_data": {"mime_type": "audio/ogg", "data": b64_audio}}
                ]
            }]
        }
        
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        data = response.json()
        transcription = data['candidates'][0]['content']['parts'][0]['text'].strip()
        
        await status_msg.delete()
        # Enviar el texto como orden
        await process_core_order(update, context, transcription, is_voice=True)
        
    except Exception as e:
        await status_msg.edit_text(f"❌ *Error de Audio:* {str(e)[:200]}", parse_mode='Markdown')

# Procesador Central
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text:
        await process_core_order(update, context, update.message.text, is_voice=False)

async def process_core_order(update: Update, context: ContextTypes.DEFAULT_TYPE, user_text: str, is_voice: bool = False):
    try:
        # 1. Llamar a DeepSeek (IA 24/7) para generar una respuesta inteligente
        if not DEEPSEEK_API_KEY:
            raise Exception("No hay DEEPSEEK_API_KEY configurada.")
            
        deepseek = AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url='https://api.deepseek.com')
        system_prompt = "Eres JARVIS, la Inteligencia Artificial Central del sistema AXYNTRAX. Tu creador y jefe es el Señor YARVIS. Debes ser extremadamente elegante, conciso, respetuoso y responder siempre en español neutro perfecto. Si él te da una orden o una idea, confírmale que la has registrado en la Base de Datos y qué IA se encargará (Z.IA para diseño, MURDOCK para seguridad, MERCURY para backend, etc). No uses formato markdown agresivo ni listas largas porque serás convertido a voz."
        
        response = await deepseek.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_text}
            ],
            temperature=0.7
        )
        jarvis_reply = response.choices[0].message.content.strip()

        # 2. Enviar orden al Core API (Para que actualice el HUD)
        core_url = "http://localhost:8080/api/telegram/command"
        core_payload = {"command": user_text, "user": str(update.message.from_user.id)}
        try:
            requests.post(core_url, json=core_payload, timeout=3)
        except Exception as api_e:
            print(f"Advertencia: HUD Core no respondió: {api_e}")

        # 3. Responder al usuario
        if is_voice:
            # Responder con voz usando Edge-TTS
            status_msg = await update.message.reply_text("🎙️ _JARVIS procesando respuesta..._", parse_mode='Markdown')
            audio_path = await generar_audio(jarvis_reply)
            with open(audio_path, 'rb') as audio_file:
                await context.bot.send_voice(chat_id=update.message.chat_id, voice=audio_file)
            os.remove(audio_path)
            await status_msg.delete()
        else:
            await update.message.reply_text(f"💎 *JARVIS:*\n{jarvis_reply}", parse_mode='Markdown')

    except Exception as e:
        await update.message.reply_text(f"❌ Error en Procesamiento Gemini: {e}")

def main():
    if sys.stdout.encoding != 'utf-8':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    print("🤖 JARVIS Motor Audiovisual Iniciando...")
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('hud', hud_command))
    
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE, handle_voice))
    
    print("✅ Bot Audiovisual listo y conectado al Core API.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
